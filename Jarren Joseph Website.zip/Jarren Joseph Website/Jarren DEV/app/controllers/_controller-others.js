/***********************************************
 * INIT THIRD PARTY SCRIPTS
 ***********************************************/
(function ($) {

	'use strict';

	// Fast click
	if (typeof FastClick === 'function') {
		FastClick.attach(document.body);
	}

})(jQuery);